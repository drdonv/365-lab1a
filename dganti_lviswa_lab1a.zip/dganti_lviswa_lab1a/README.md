Team: Dhanvi Ganti, Lakshana Viswa

Compile this program by running the command "python schoolsearch.py" in your terminal. Then, use the commands below to access the data you would like. The brackets indicate optional parameters.

• S[tudent]: <lastname> [B[us]]
• T[eacher]: <lastname>
• B[us]: <number>
• G[rade]: <number> [H[igh]|L[ow]]
• A[verage]: <number>
• I[nfo]
• Q[uit]
