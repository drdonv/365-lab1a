Team: Dhanvi Ganti, Lakshana Viswa

Compile this program by running the command "python schoolsearch.py" in your terminal. Then, use the commands below to access the data you would like. The brackets indicate optional parameters.

• S[tudent]: <lastname> [B[us]] # Find data on a student by last name. Include the optional bus parameter to get bus info
• T[eacher]: <lastname> # Retrieve names of students teacher teaches
• B[us]: <number> # Display info about a certain bus number
• G[rade]: <number> [H[igh]|L[ow]] # Display info about a grade and optionally the highest/lowest of the grade
• A[verage]: <number> # Average GPA info of a given grade
• I[nfo]
• Q[uit]
• C[lassroom]: <number> # Returns students of a classroom
• FindTeacher: <number> # Returns the name of a teacher assigned to a given classroom number
• GradeTeachers: <number> # Returns all teachers teaching a certain grade
• E[nrollments] # Enrollment info of each classroom
• Average:/Avg: <number> # Returns average GPA of a student in a certain grade
• A[nalytics]: <"GradeGPA" / "TeacherGPA" / "BusGPA"> # Find the average GPA of students, GPA by teacher, or GPA by bus
• FindTeacher: <number> # Find the teacher for a given classroom number
